// Import of unsuspicious documents (Google Doc exports) into Supabase.
//
// Run from the project folder (everything-log):
//   node --env-file=.env.local journal-import/import.mjs --dry   ← just shows what it would do
//   node --env-file=.env.local journal-import/import.mjs         ← does it
//
// Safe to run again: any day that already has an entry in Supabase is skipped (never overwritten),
// except the days listed under "replace" in meta.json (days an earlier test import wrote
// differently), which are swapped for the version in this file.

import { readFileSync } from "node:fs";
import { randomUUID } from "node:crypto";
import { createClient } from "@supabase/supabase-js";

const here = new URL("./", import.meta.url);
const meta = JSON.parse(readFileSync(new URL("meta.json", here), "utf8"));
const replace = new Set(meta.replace ?? []);
const entries = JSON.parse(readFileSync(new URL("entries.json", here), "utf8"));
const dry = process.argv.includes("--dry");
const pictures = entries.reduce((n, e) => n + (e.body.match(/<img /g) ?? []).length, 0);
console.log(`${entries.length} entries, ${pictures} pictures (${entries[0].date} → ${entries.at(-1).date}).`);

if (dry) {
  for (const e of entries) {
    const words = e.body.replace(/<[^>]+>/g, " ").split(/\s+/).filter(Boolean).length;
    const pics = (e.body.match(/<img /g) ?? []).length;
    console.log(`  ${e.date}  ${String(words).padStart(5)} words${pics ? `  + ${pics} picture(s)` : ""}`);
  }
  console.log("Dry run: nothing was saved.");
  process.exit(0);
}

const { SUPABASE_URL, SUPABASE_SECRET_KEY } = process.env;
if (!SUPABASE_URL || !SUPABASE_SECRET_KEY) {
  console.error("Missing Supabase keys. Run it from the project folder with: node --env-file=.env.local journal-import/import.mjs");
  process.exit(1);
}
const db = createClient(SUPABASE_URL, SUPABASE_SECRET_KEY, { auth: { persistSession: false } });

// Days already in Supabase (skipped).
const { data: existing, error } = await db
  .from("journal_entries")
  .select("entry_date")
  .in("entry_date", entries.map((e) => e.date));
if (error) {
  console.error("Couldn't read the journal table:", error.message, "\nDid you run supabase/journal.sql?");
  process.exit(1);
}
const already = new Set(existing.map((e) => e.entry_date).filter((d) => !replace.has(d)));
const skipped = [];

const TYPES = { png: "image/png", jpg: "image/jpeg", jpeg: "image/jpeg", gif: "image/gif", webp: "image/webp" };
let added = 0;
for (const entry of entries) {
  if (already.has(entry.date)) {
    skipped.push(entry.date);
    continue;
  }
  // Upload this entry's pictures and point the text at them.
  let body = entry.body;
  for (const file of [...new Set(body.match(/data-file="[^"]+"/g)?.map((m) => m.slice(11, -1)) ?? [])]) {
    const ext = file.split(".").pop().toLowerCase();
    const path = `${randomUUID()}.${ext === "jpeg" ? "jpg" : ext}`;
    const up = await db.storage
      .from("journal-images")
      .upload(path, readFileSync(new URL(`images/${file}`, here)), { contentType: TYPES[ext] ?? "image/png" });
    if (up.error) {
      console.error(`Picture upload failed on ${entry.date}:`, up.error.message);
      process.exit(1);
    }
    body = body.split(`data-file="${file}"`).join(`data-path="${path}"`);
  }
  // Replacing a day from an earlier import: remember its old pictures so they can be removed.
  let oldPictures = [];
  if (replace.has(entry.date)) {
    const old = await db.from("journal_entries").select("body").eq("entry_date", entry.date).maybeSingle();
    oldPictures = [...(old.data?.body ?? "").matchAll(/data-path="([^"]+)"/g)].map((m) => m[1]);
  }
  const res = replace.has(entry.date)
    ? await db.from("journal_entries").upsert({ entry_date: entry.date, body, updated_at: new Date().toISOString() }, { onConflict: "entry_date" })
    : await db.from("journal_entries").insert({ entry_date: entry.date, body });
  if (res.error) {
    console.error(`Failed on ${entry.date}:`, res.error.message, "\nFix the problem and run it again; finished days are skipped.");
    process.exit(1);
  }
  if (oldPictures.length > 0) await db.storage.from("journal-images").remove(oldPictures);
  added++;
  console.log(`  ✓ ${entry.date}`);
}

// Make these documents school years (only where it hasn't been set yet).
for (const d of meta.docs ?? []) {
  const doc = await db.from("journal_docs").select("year").eq("year", d.year).maybeSingle();
  if (!doc.data) await db.from("journal_docs").insert({ year: d.year, start_month: d.start_month });
}

// Add each document's card to the "Unsuspicious documents" category on the home page (if missing).
const cat = await db.from("home_categories").select("id").ilike("name", "unsuspicious documents").limit(1).maybeSingle();
if (!cat.data) {
  console.log('No "Unsuspicious documents" category found, so no cards were added. Add them from the home page (Edit).');
} else {
  for (const d of meta.docs ?? []) {
    const href = `/journal/${d.year}`;
    const has = await db.from("home_items").select("id").eq("href", href).limit(1).maybeSingle();
    if (has.data) continue;
    const { count } = await db.from("home_items").select("id", { count: "exact", head: true }).eq("category_id", cat.data.id);
    const res = await db.from("home_items").insert({ category_id: cat.data.id, name: d.name, href, position: count ?? 0 });
    console.log(res.error ? `Couldn't add the card for ${d.year}: ${res.error.message}` : `  + card: ${d.name}`);
  }
}

if (skipped.length > 0) {
  console.log(`\nSkipped ${skipped.length} day(s) that already had an entry (from an earlier import, or written in the app):`);
  console.log("  " + skipped.join(", "));
}
console.log(`Done. Added ${added} entries. You can delete the journal-import folder now.`);
